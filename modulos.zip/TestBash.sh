#!/bin/sh
while :
do
        cat "/proc/serverRam" > "dataRam.txt"
		chmod +rwx "dataRam.txt"
		chmod g+rwx "dataRam.txt"
		chmod o+rwx "dataRam.txt"
		cat "/proc/serverProcs2" > "dataProcs.txt"
		chmod +rwx "dataProcs.txt"
		chmod g+rwx "dataProcs.txt"
		chmod o+rwx "dataProcs.txt"
        sleep 3
done