/****************
* SE UTILIZÓ CODIGO DE REFERENCIA DE GITHUB
* https://github.com/01org/KVMGT-kernel/blob/master/fs/proc/meminfo.c
* AUTOR: @paulgortmaker
* 
*****************/

#include <linux/fs.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/hugetlb.h>
#include <linux/module.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>

#define K(x) ((x) << (PAGE_SHIFT - 10))

static int meminfo_proc_show(struct seq_file *m, void *v)
{
    struct sysinfo i;
    unsigned long pages[NR_LRU_LISTS];
    int lru;
	
    si_meminfo(&i);
    for (lru = LRU_BASE; lru < NR_LRU_LISTS; lru++)
        pages[lru] = global_numa_state(NR_LRU_BASE + lru);        
        //CREAR EL JSON, LA FUNCION K() devuelve el equivalente en kb,
        //se divide por 1024 para obtener los megas
    seq_printf(m, "{");
    seq_printf(m, "\"ram\":%lu,",K(i.totalram)/1024);
    seq_printf(m, "\"used\":%lu,",(K(i.totalram)-K(i.freeram))/1024);
    seq_printf(m, "\"free\":%lu",K(i.freeram)/1024);
    seq_printf(m, "}");
	
    return 0;
}

static void __exit final(void) //Salida de modulo
{
    printk(KERN_INFO "Sayonaramundo, somos el grupo 2 y este fue el monitor de memoria.\n");
	remove_proc_entry("serverRam",NULL);
}

static int meminfo_proc_open(struct inode *inode, struct file *file)
{
    return single_open(file, meminfo_proc_show, NULL);
}

static const struct file_operations meminfo_proc_fops = {
    .open = meminfo_proc_open,
    .read = seq_read,
    .llseek = seq_lseek,
    .release = single_release,
};

static int __init inicio(void) //Escribe archivo en /proc
{
	printk(KERN_INFO "Hola mundo, somos el grupo 2 y este es el monitor de memoria.\n");
    proc_create("serverRam", 0777, NULL, &meminfo_proc_fops);
    return 0;
}

module_init(inicio);
module_exit(final);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("GRUPO2");
MODULE_DESCRIPTION("RAM");
