#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/proc_fs.h>
#include <linux/sched.h>
#include <linux/sched/signal.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/fs.h>
#include <linux/sysinfo.h>
#include <linux/seq_file.h>
#include <linux/slab.h>
#include <linux/mm.h>
#include <linux/cred.h>
#include <linux/sched.h>
#include <linux/swap.h>

static int sysinfo_proc_show(struct seq_file *m, void *v)
{
	struct task_struct *task;

	seq_printf(m,"[{\"DATA\":\"INIT\"}");

	for_each_process(task){
		if(task->mm){
			long bytesUsed = task->mm->total_vm << PAGE_SHIFT;
			if( task->parent ){
				seq_printf(m,",{\"parent\":%d,\"id\":%d,\"name\":\"%s\",\"usrid\":%d,\"state\":%ld,\"size\":%ld}", task->parent->pid, task->pid, task->comm, task->cred->uid.val, task->state, bytesUsed);
			} else {
				seq_printf(m,",{\"parent\":-1,\"id\":%d,\"name\":\"%s\",\"usrid\":%d,\"state\":%ld,\"size\":%ld}", task->pid, task->comm, task->cred->uid.val, task->state, bytesUsed);
			}
		}
	}
	
	seq_printf(m,"]");
	
    return 0;
}

static void __exit final(void) //Salida de modulo
{
    printk(KERN_INFO "Sayonaramundo, somos el grupo 2 y este fue el monitor de tareas.\n");
	remove_proc_entry("serverProcs2",NULL);
}

static int sysinfo_proc_open(struct inode *inode, struct file *file)
{
    return single_open(file, sysinfo_proc_show, NULL);
}

static const struct file_operations sysinfo_proc_fops = {
    .open = sysinfo_proc_open,
    .read = seq_read,
    .llseek = seq_lseek,
    .release = single_release,
};

static int __init inicio(void) //Escribe archivo en /proc
{
	printk(KERN_INFO "Hola mundo, somos el grupo 2 y este es el monitor de tareas.\n");
    proc_create("serverProcs2", 0777, NULL, &sysinfo_proc_fops);
    return 0;
}

module_init(inicio);
module_exit(final);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("GRUPO2");
MODULE_DESCRIPTION("PROCS");
